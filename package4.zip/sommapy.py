import requests

def post(event, context):
	data = event["data"]
	x = requests.post('http://10.152.183.47:8080', data=data)
	data2 = data.decode().split(',')
	a = int(x.text)
	b = int(data2[1])
	somma = a + b
	return f"{somma}"
