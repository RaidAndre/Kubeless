import requests

def post(event, context):
	data = event["data"]
	x = requests.post('http://10.152.183.142:8080', data=data)
	data2 = data.decode().split(',')
	a = int(x.text)
	b = int(data2[2])
	moltiplica = a * b
	return f"{moltiplica}"
