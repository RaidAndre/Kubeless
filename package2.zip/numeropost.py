import requests

def post(event, context):
	data = '5'
	x = requests.post('http://10.152.183.39:8080', data = data)
	sum = x + 5
	return "{}".format(sum)
