import requests

def post(event, context):
	data = event["data"]
	x = requests.post('http://10.152.183.39:8080', data=data)
	a = int(x.text)
	somma = a + 5
	return f"{somma}"
