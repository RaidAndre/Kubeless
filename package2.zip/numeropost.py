import requests

def post(event, context):
	data = '5'
	x = requests.post('http://10.152.183.39:8080', data=data)
	somma = x.text + 2
	return f"{somma}"
