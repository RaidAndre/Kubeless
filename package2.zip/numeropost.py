import requests

def post(event, context):
	data = '5'
	x = requests.post('http://10.152.183.39:8080', data = data)
	y = int(request.Response.text)
	sum = y + 5
	return "{}".format(sum)
