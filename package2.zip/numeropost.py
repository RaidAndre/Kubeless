import requests

def post(event, context):
	data = int(event["data"])
	x = requests.post('http://10.152.183.39:8080', data=data)
	return x.text
