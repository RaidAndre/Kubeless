import requests

def post(event, context):
	url = "http://10.152.183.34:8080/"
	myobj = int(event["data"])

	x = requests.post(url, data = myobj)
	sum = x + 5
	return "{}".format(sum)
