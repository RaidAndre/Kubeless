import requests

def post(event, context):
	data = event["data"]
	x = requests.post('http://10.152.183.44:8080', data=data)
	a = int(x.text)
	moltiply = a * 2
	return f"{moltiply}"
